#include <stdio.h>

extern void show();

int main(){
	show();
	printf("Teste\n");
	return 0;
}
