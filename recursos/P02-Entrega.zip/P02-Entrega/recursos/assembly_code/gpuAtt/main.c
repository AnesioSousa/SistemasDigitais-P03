#include <stdio.h>

extern void mem_map();
extern void set_background_color();
extern void clear_background();


int main() {
  mem_map();

  return 0;
}
