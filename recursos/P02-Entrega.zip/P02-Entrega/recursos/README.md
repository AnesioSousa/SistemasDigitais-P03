# Tetris 
Um clássico atemporal que cativa gerações de jogadores.

## Como executar o jogo

# Instalar a biblioteca ncurses utilizada para controlar o tempo no jogo
```
$ sudo apt-get install libncurses5-dev libncursesw5-dev
```

# Rodar o game
```
$ make
```

## Referências:
NAJIBGHADRI. Disponivel em: <https://github.com/najibghadri/Tetris200lines/tree/master>. Acesso em: 03/09/2024
